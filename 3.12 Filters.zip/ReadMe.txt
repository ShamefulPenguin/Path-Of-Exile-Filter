You've added and downloaded some custom sounds for you filter. Those sound files need to be placed in the same folder as your filter file.

This is a list of all used custom sounds:
- 6veryvaluable.mp3
- 1maybevaluable.mp3
- 3uniques.mp3
- 2currency.mp3
- 12leveling.mp3
- 4maps.mp3
- 5highmaps.mp3
